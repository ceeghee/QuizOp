﻿namespace QuizOP
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblID = new System.Windows.Forms.Label();
            this.lblNM4 = new System.Windows.Forms.Label();
            this.lblNm1 = new System.Windows.Forms.Label();
            this.lblNM2 = new System.Windows.Forms.Label();
            this.lblNM3 = new System.Windows.Forms.Label();
            this.lblTeam = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pnInst = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.lbl_NM4 = new System.Windows.Forms.Label();
            this.lbl_NM1 = new System.Windows.Forms.Label();
            this.lbl_NM2 = new System.Windows.Forms.Label();
            this.lbl_NM3 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_Team = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.CountdownTimer = new System.Windows.Forms.Timer(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblQuestTeam6 = new System.Windows.Forms.Label();
            this.lblQuestTeam4 = new System.Windows.Forms.Label();
            this.lblQuestTeam3 = new System.Windows.Forms.Label();
            this.lblQuest10 = new System.Windows.Forms.Label();
            this.lblQuest9 = new System.Windows.Forms.Label();
            this.lblQuest8 = new System.Windows.Forms.Label();
            this.lblQuest7 = new System.Windows.Forms.Label();
            this.lblQuest6 = new System.Windows.Forms.Label();
            this.lblQuest5 = new System.Windows.Forms.Label();
            this.lblQuest4 = new System.Windows.Forms.Label();
            this.lblQuest3 = new System.Windows.Forms.Label();
            this.lblQuest2 = new System.Windows.Forms.Label();
            this.lblPoint2 = new System.Windows.Forms.Label();
            this.lblPoints = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.lblQuestTeam2 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblCountTeam2 = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.lblVersus = new System.Windows.Forms.Label();
            this.lblCorrect = new System.Windows.Forms.Label();
            this.lblWrong = new System.Windows.Forms.Label();
            this.lblWrong2 = new System.Windows.Forms.Label();
            this.lblCorrect2 = new System.Windows.Forms.Label();
            this.lblLost = new System.Windows.Forms.Label();
            this.lblTeam2 = new iTalk.iTalk_HeaderLabel();
            this.lblTeam1 = new iTalk.iTalk_HeaderLabel();
            this.btnNext = new iTalk.iTalk_Button_1();
            this.btnNext2 = new iTalk.iTalk_Button_1();
            this.panel1.SuspendLayout();
            this.pnInst.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "TEAM :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.lblID);
            this.panel1.Controls.Add(this.lblNM4);
            this.panel1.Controls.Add(this.lblNm1);
            this.panel1.Controls.Add(this.lblNM2);
            this.panel1.Controls.Add(this.lblNM3);
            this.panel1.Controls.Add(this.lblTeam);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(11, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(316, 221);
            this.panel1.TabIndex = 1;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(197, 6);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(85, 13);
            this.lblID.TabIndex = 10;
            this.lblID.Text = "No of Members :";
            this.lblID.Visible = false;
            // 
            // lblNM4
            // 
            this.lblNM4.AutoSize = true;
            this.lblNM4.Location = new System.Drawing.Point(3, 157);
            this.lblNM4.Name = "lblNM4";
            this.lblNM4.Size = new System.Drawing.Size(85, 13);
            this.lblNM4.TabIndex = 9;
            this.lblNM4.Text = "No of Members :";
            // 
            // lblNm1
            // 
            this.lblNm1.AutoSize = true;
            this.lblNm1.Location = new System.Drawing.Point(3, 69);
            this.lblNm1.Name = "lblNm1";
            this.lblNm1.Size = new System.Drawing.Size(85, 13);
            this.lblNm1.TabIndex = 5;
            this.lblNm1.Text = "No of Members :";
            // 
            // lblNM2
            // 
            this.lblNM2.AutoSize = true;
            this.lblNM2.Location = new System.Drawing.Point(3, 99);
            this.lblNM2.Name = "lblNM2";
            this.lblNM2.Size = new System.Drawing.Size(85, 13);
            this.lblNM2.TabIndex = 4;
            this.lblNM2.Text = "No of Members :";
            // 
            // lblNM3
            // 
            this.lblNM3.AutoSize = true;
            this.lblNM3.Location = new System.Drawing.Point(3, 129);
            this.lblNM3.Name = "lblNM3";
            this.lblNM3.Size = new System.Drawing.Size(85, 13);
            this.lblNM3.TabIndex = 3;
            this.lblNM3.Text = "No of Members :";
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Location = new System.Drawing.Point(52, 6);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(85, 13);
            this.lblTeam.TabIndex = 2;
            this.lblTeam.Text = "No of Members :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Name of Members :";
            // 
            // pnInst
            // 
            this.pnInst.BackColor = System.Drawing.Color.Silver;
            this.pnInst.Controls.Add(this.button1);
            this.pnInst.Controls.Add(this.label3);
            this.pnInst.Controls.Add(this.label2);
            this.pnInst.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnInst.Location = new System.Drawing.Point(11, 56);
            this.pnInst.Name = "pnInst";
            this.pnInst.Size = new System.Drawing.Size(761, 99);
            this.pnInst.TabIndex = 2;
            this.pnInst.Paint += new System.Windows.Forms.PaintEventHandler(this.pnInst_Paint);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(666, 63);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 33);
            this.button1.TabIndex = 2;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(743, 52);
            this.label3.TabIndex = 1;
            this.label3.Text = resources.GetString("label3.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(243, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Read The Following Instructions Carefully";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.PowderBlue;
            this.panel2.Controls.Add(this.lbl_ID);
            this.panel2.Controls.Add(this.lbl_NM4);
            this.panel2.Controls.Add(this.lbl_NM1);
            this.panel2.Controls.Add(this.lbl_NM2);
            this.panel2.Controls.Add(this.lbl_NM3);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.lbl_Team);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Location = new System.Drawing.Point(943, 55);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(316, 221);
            this.panel2.TabIndex = 3;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Location = new System.Drawing.Point(199, 6);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(85, 13);
            this.lbl_ID.TabIndex = 21;
            this.lbl_ID.Text = "No of Members :";
            this.lbl_ID.Visible = false;
            // 
            // lbl_NM4
            // 
            this.lbl_NM4.AutoSize = true;
            this.lbl_NM4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NM4.Location = new System.Drawing.Point(3, 157);
            this.lbl_NM4.Name = "lbl_NM4";
            this.lbl_NM4.Size = new System.Drawing.Size(98, 15);
            this.lbl_NM4.TabIndex = 20;
            this.lbl_NM4.Text = "No of Members :";
            // 
            // lbl_NM1
            // 
            this.lbl_NM1.AutoSize = true;
            this.lbl_NM1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NM1.Location = new System.Drawing.Point(3, 69);
            this.lbl_NM1.Name = "lbl_NM1";
            this.lbl_NM1.Size = new System.Drawing.Size(98, 15);
            this.lbl_NM1.TabIndex = 19;
            this.lbl_NM1.Text = "No of Members :";
            // 
            // lbl_NM2
            // 
            this.lbl_NM2.AutoSize = true;
            this.lbl_NM2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NM2.Location = new System.Drawing.Point(3, 99);
            this.lbl_NM2.Name = "lbl_NM2";
            this.lbl_NM2.Size = new System.Drawing.Size(98, 15);
            this.lbl_NM2.TabIndex = 18;
            this.lbl_NM2.Text = "No of Members :";
            // 
            // lbl_NM3
            // 
            this.lbl_NM3.AutoSize = true;
            this.lbl_NM3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NM3.Location = new System.Drawing.Point(3, 129);
            this.lbl_NM3.Name = "lbl_NM3";
            this.lbl_NM3.Size = new System.Drawing.Size(98, 15);
            this.lbl_NM3.TabIndex = 17;
            this.lbl_NM3.Text = "No of Members :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(3, 39);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(116, 13);
            this.label22.TabIndex = 16;
            this.label22.Text = "Name of Members :";
            // 
            // lbl_Team
            // 
            this.lbl_Team.AutoSize = true;
            this.lbl_Team.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Team.Location = new System.Drawing.Point(65, 8);
            this.lbl_Team.Name = "lbl_Team";
            this.lbl_Team.Size = new System.Drawing.Size(109, 17);
            this.lbl_Team.TabIndex = 9;
            this.lbl_Team.Text = "No of Members :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 15);
            this.label16.TabIndex = 7;
            this.label16.Text = "TEAM :";
            // 
            // CountdownTimer
            // 
            this.CountdownTimer.Enabled = true;
            this.CountdownTimer.Interval = 1000;
            this.CountdownTimer.Tick += new System.EventHandler(this.CountdownTimer_Tick);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel3.Controls.Add(this.lblWrong2);
            this.panel3.Controls.Add(this.lblCorrect2);
            this.panel3.Controls.Add(this.lblWrong);
            this.panel3.Controls.Add(this.lblCorrect);
            this.panel3.Controls.Add(this.lblQuestTeam6);
            this.panel3.Controls.Add(this.lblQuestTeam4);
            this.panel3.Controls.Add(this.lblQuestTeam3);
            this.panel3.Controls.Add(this.lblQuest10);
            this.panel3.Controls.Add(this.lblQuest9);
            this.panel3.Controls.Add(this.lblQuest8);
            this.panel3.Controls.Add(this.lblQuest7);
            this.panel3.Controls.Add(this.lblQuest6);
            this.panel3.Controls.Add(this.lblQuest5);
            this.panel3.Controls.Add(this.lblQuest4);
            this.panel3.Controls.Add(this.lblQuest3);
            this.panel3.Controls.Add(this.lblQuest2);
            this.panel3.Controls.Add(this.lblPoint2);
            this.panel3.Controls.Add(this.lblPoints);
            this.panel3.Controls.Add(this.lblTeam2);
            this.panel3.Controls.Add(this.lblTeam1);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.lblQuestTeam2);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.lblCountTeam2);
            this.panel3.Controls.Add(this.lblCount);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.lblQuestion);
            this.panel3.Controls.Add(this.radioButton4);
            this.panel3.Controls.Add(this.radioButton3);
            this.panel3.Controls.Add(this.radioButton2);
            this.panel3.Controls.Add(this.radioButton1);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(2, 305);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1257, 307);
            this.panel3.TabIndex = 4;
            // 
            // lblQuestTeam6
            // 
            this.lblQuestTeam6.AutoSize = true;
            this.lblQuestTeam6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestTeam6.Location = new System.Drawing.Point(863, 13);
            this.lblQuestTeam6.Name = "lblQuestTeam6";
            this.lblQuestTeam6.Size = new System.Drawing.Size(64, 16);
            this.lblQuestTeam6.TabIndex = 37;
            this.lblQuestTeam6.Text = "POINTS :";
            this.lblQuestTeam6.Visible = false;
            // 
            // lblQuestTeam4
            // 
            this.lblQuestTeam4.AutoSize = true;
            this.lblQuestTeam4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestTeam4.Location = new System.Drawing.Point(793, 13);
            this.lblQuestTeam4.Name = "lblQuestTeam4";
            this.lblQuestTeam4.Size = new System.Drawing.Size(64, 16);
            this.lblQuestTeam4.TabIndex = 36;
            this.lblQuestTeam4.Text = "POINTS :";
            this.lblQuestTeam4.Visible = false;
            // 
            // lblQuestTeam3
            // 
            this.lblQuestTeam3.AutoSize = true;
            this.lblQuestTeam3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestTeam3.Location = new System.Drawing.Point(711, 13);
            this.lblQuestTeam3.Name = "lblQuestTeam3";
            this.lblQuestTeam3.Size = new System.Drawing.Size(64, 16);
            this.lblQuestTeam3.TabIndex = 35;
            this.lblQuestTeam3.Text = "POINTS :";
            this.lblQuestTeam3.Visible = false;
            // 
            // lblQuest10
            // 
            this.lblQuest10.AutoSize = true;
            this.lblQuest10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest10.Location = new System.Drawing.Point(160, 29);
            this.lblQuest10.Name = "lblQuest10";
            this.lblQuest10.Size = new System.Drawing.Size(64, 16);
            this.lblQuest10.TabIndex = 34;
            this.lblQuest10.Text = "POINTS :";
            this.lblQuest10.Visible = false;
            // 
            // lblQuest9
            // 
            this.lblQuest9.AutoSize = true;
            this.lblQuest9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest9.Location = new System.Drawing.Point(78, 29);
            this.lblQuest9.Name = "lblQuest9";
            this.lblQuest9.Size = new System.Drawing.Size(64, 16);
            this.lblQuest9.TabIndex = 33;
            this.lblQuest9.Text = "POINTS :";
            this.lblQuest9.Visible = false;
            // 
            // lblQuest8
            // 
            this.lblQuest8.AutoSize = true;
            this.lblQuest8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest8.Location = new System.Drawing.Point(493, 13);
            this.lblQuest8.Name = "lblQuest8";
            this.lblQuest8.Size = new System.Drawing.Size(64, 16);
            this.lblQuest8.TabIndex = 32;
            this.lblQuest8.Text = "POINTS :";
            this.lblQuest8.Visible = false;
            // 
            // lblQuest7
            // 
            this.lblQuest7.AutoSize = true;
            this.lblQuest7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest7.Location = new System.Drawing.Point(440, 13);
            this.lblQuest7.Name = "lblQuest7";
            this.lblQuest7.Size = new System.Drawing.Size(64, 16);
            this.lblQuest7.TabIndex = 31;
            this.lblQuest7.Text = "POINTS :";
            this.lblQuest7.Visible = false;
            // 
            // lblQuest6
            // 
            this.lblQuest6.AutoSize = true;
            this.lblQuest6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest6.Location = new System.Drawing.Point(370, 13);
            this.lblQuest6.Name = "lblQuest6";
            this.lblQuest6.Size = new System.Drawing.Size(64, 16);
            this.lblQuest6.TabIndex = 30;
            this.lblQuest6.Text = "POINTS :";
            this.lblQuest6.Visible = false;
            // 
            // lblQuest5
            // 
            this.lblQuest5.AutoSize = true;
            this.lblQuest5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest5.Location = new System.Drawing.Point(300, 13);
            this.lblQuest5.Name = "lblQuest5";
            this.lblQuest5.Size = new System.Drawing.Size(64, 16);
            this.lblQuest5.TabIndex = 29;
            this.lblQuest5.Text = "POINTS :";
            this.lblQuest5.Visible = false;
            // 
            // lblQuest4
            // 
            this.lblQuest4.AutoSize = true;
            this.lblQuest4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest4.Location = new System.Drawing.Point(230, 13);
            this.lblQuest4.Name = "lblQuest4";
            this.lblQuest4.Size = new System.Drawing.Size(64, 16);
            this.lblQuest4.TabIndex = 28;
            this.lblQuest4.Text = "POINTS :";
            this.lblQuest4.Visible = false;
            // 
            // lblQuest3
            // 
            this.lblQuest3.AutoSize = true;
            this.lblQuest3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest3.Location = new System.Drawing.Point(160, 13);
            this.lblQuest3.Name = "lblQuest3";
            this.lblQuest3.Size = new System.Drawing.Size(64, 16);
            this.lblQuest3.TabIndex = 27;
            this.lblQuest3.Text = "POINTS :";
            this.lblQuest3.Visible = false;
            // 
            // lblQuest2
            // 
            this.lblQuest2.AutoSize = true;
            this.lblQuest2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest2.Location = new System.Drawing.Point(78, 13);
            this.lblQuest2.Name = "lblQuest2";
            this.lblQuest2.Size = new System.Drawing.Size(64, 16);
            this.lblQuest2.TabIndex = 13;
            this.lblQuest2.Text = "POINTS :";
            this.lblQuest2.Visible = false;
            // 
            // lblPoint2
            // 
            this.lblPoint2.AutoSize = true;
            this.lblPoint2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPoint2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoint2.ForeColor = System.Drawing.Color.Green;
            this.lblPoint2.Location = new System.Drawing.Point(659, 253);
            this.lblPoint2.Name = "lblPoint2";
            this.lblPoint2.Size = new System.Drawing.Size(100, 36);
            this.lblPoint2.TabIndex = 26;
            this.lblPoint2.Text = "Count";
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoints.ForeColor = System.Drawing.Color.Green;
            this.lblPoints.Location = new System.Drawing.Point(9, 253);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(100, 36);
            this.lblPoints.TabIndex = 25;
            this.lblPoints.Text = "Count";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.radioButton8);
            this.panel7.Controls.Add(this.radioButton7);
            this.panel7.Controls.Add(this.radioButton6);
            this.panel7.Controls.Add(this.radioButton5);
            this.panel7.Location = new System.Drawing.Point(655, 107);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(373, 107);
            this.panel7.TabIndex = 22;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton8.Location = new System.Drawing.Point(3, 3);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(101, 20);
            this.radioButton8.TabIndex = 13;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "radioButton8";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton7.Location = new System.Drawing.Point(3, 26);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(101, 20);
            this.radioButton7.TabIndex = 14;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "radioButton7";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton6.Location = new System.Drawing.Point(3, 49);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(101, 20);
            this.radioButton6.TabIndex = 15;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "radioButton6";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton5.Location = new System.Drawing.Point(3, 72);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(101, 20);
            this.radioButton5.TabIndex = 16;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "radioButton5";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // lblQuestTeam2
            // 
            this.lblQuestTeam2.AutoSize = true;
            this.lblQuestTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestTeam2.Location = new System.Drawing.Point(641, 13);
            this.lblQuestTeam2.Name = "lblQuestTeam2";
            this.lblQuestTeam2.Size = new System.Drawing.Size(64, 16);
            this.lblQuestTeam2.TabIndex = 21;
            this.lblQuestTeam2.Text = "POINTS :";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Red;
            this.panel6.Location = new System.Drawing.Point(563, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(71, 49);
            this.panel6.TabIndex = 20;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Red;
            this.panel5.Location = new System.Drawing.Point(3, 45);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1254, 10);
            this.panel5.TabIndex = 19;
            // 
            // lblCountTeam2
            // 
            this.lblCountTeam2.AutoSize = true;
            this.lblCountTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountTeam2.ForeColor = System.Drawing.Color.Green;
            this.lblCountTeam2.Location = new System.Drawing.Point(1064, 149);
            this.lblCountTeam2.Name = "lblCountTeam2";
            this.lblCountTeam2.Size = new System.Drawing.Size(67, 36);
            this.lblCountTeam2.TabIndex = 12;
            this.lblCountTeam2.Text = "15s";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.ForeColor = System.Drawing.Color.Green;
            this.lblCount.Location = new System.Drawing.Point(337, 149);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(67, 36);
            this.lblCount.TabIndex = 10;
            this.lblCount.Text = "15s";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Red;
            this.panel4.Controls.Add(this.btnNext);
            this.panel4.Controls.Add(this.btnNext2);
            this.panel4.Location = new System.Drawing.Point(564, 55);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(69, 249);
            this.panel4.TabIndex = 9;
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(8, 13);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(64, 16);
            this.lblQuestion.TabIndex = 8;
            this.lblQuestion.Text = "POINTS :";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.Location = new System.Drawing.Point(6, 194);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(101, 20);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "radioButton4";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.Location = new System.Drawing.Point(6, 171);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(101, 20);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(6, 148);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(101, 20);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(6, 125);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(101, 20);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // lblVersus
            // 
            this.lblVersus.AutoSize = true;
            this.lblVersus.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersus.ForeColor = System.Drawing.Color.Red;
            this.lblVersus.Location = new System.Drawing.Point(554, 162);
            this.lblVersus.Name = "lblVersus";
            this.lblVersus.Size = new System.Drawing.Size(101, 63);
            this.lblVersus.TabIndex = 12;
            this.lblVersus.Text = "VS";
            // 
            // lblCorrect
            // 
            this.lblCorrect.AutoSize = true;
            this.lblCorrect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCorrect.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorrect.ForeColor = System.Drawing.Color.Green;
            this.lblCorrect.Location = new System.Drawing.Point(264, 253);
            this.lblCorrect.Name = "lblCorrect";
            this.lblCorrect.Size = new System.Drawing.Size(119, 36);
            this.lblCorrect.TabIndex = 38;
            this.lblCorrect.Text = "Correct";
            this.lblCorrect.Visible = false;
            // 
            // lblWrong
            // 
            this.lblWrong.AutoSize = true;
            this.lblWrong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWrong.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWrong.ForeColor = System.Drawing.Color.Red;
            this.lblWrong.Location = new System.Drawing.Point(389, 253);
            this.lblWrong.Name = "lblWrong";
            this.lblWrong.Size = new System.Drawing.Size(110, 36);
            this.lblWrong.TabIndex = 39;
            this.lblWrong.Text = "Wrong";
            this.lblWrong.Visible = false;
            // 
            // lblWrong2
            // 
            this.lblWrong2.AutoSize = true;
            this.lblWrong2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblWrong2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWrong2.ForeColor = System.Drawing.Color.Red;
            this.lblWrong2.Location = new System.Drawing.Point(1097, 253);
            this.lblWrong2.Name = "lblWrong2";
            this.lblWrong2.Size = new System.Drawing.Size(110, 36);
            this.lblWrong2.TabIndex = 41;
            this.lblWrong2.Text = "Wrong";
            this.lblWrong2.Visible = false;
            // 
            // lblCorrect2
            // 
            this.lblCorrect2.AutoSize = true;
            this.lblCorrect2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCorrect2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorrect2.ForeColor = System.Drawing.Color.Green;
            this.lblCorrect2.Location = new System.Drawing.Point(972, 253);
            this.lblCorrect2.Name = "lblCorrect2";
            this.lblCorrect2.Size = new System.Drawing.Size(119, 36);
            this.lblCorrect2.TabIndex = 40;
            this.lblCorrect2.Text = "Correct";
            this.lblCorrect2.Visible = false;
            // 
            // lblLost
            // 
            this.lblLost.AutoSize = true;
            this.lblLost.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLost.ForeColor = System.Drawing.Color.Red;
            this.lblLost.Location = new System.Drawing.Point(436, 220);
            this.lblLost.Name = "lblLost";
            this.lblLost.Size = new System.Drawing.Size(65, 39);
            this.lblLost.TabIndex = 13;
            this.lblLost.Text = "VS";
            this.lblLost.Visible = false;
            // 
            // lblTeam2
            // 
            this.lblTeam2.AutoSize = true;
            this.lblTeam2.BackColor = System.Drawing.Color.Transparent;
            this.lblTeam2.Font = new System.Drawing.Font("Segoe UI", 25F);
            this.lblTeam2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.lblTeam2.Location = new System.Drawing.Point(809, 58);
            this.lblTeam2.Name = "lblTeam2";
            this.lblTeam2.Size = new System.Drawing.Size(304, 46);
            this.lblTeam2.TabIndex = 24;
            this.lblTeam2.Text = "iTalk_HeaderLabel2";
            // 
            // lblTeam1
            // 
            this.lblTeam1.AutoSize = true;
            this.lblTeam1.BackColor = System.Drawing.Color.Transparent;
            this.lblTeam1.Font = new System.Drawing.Font("Segoe UI", 25F);
            this.lblTeam1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.lblTeam1.Location = new System.Drawing.Point(118, 58);
            this.lblTeam1.Name = "lblTeam1";
            this.lblTeam1.Size = new System.Drawing.Size(304, 46);
            this.lblTeam1.TabIndex = 23;
            this.lblTeam1.Text = "iTalk_HeaderLabel1";
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.Transparent;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnNext.Image = null;
            this.btnNext.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNext.Location = new System.Drawing.Point(1, 84);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(69, 52);
            this.btnNext.TabIndex = 11;
            this.btnNext.Text = "Next";
            this.btnNext.TextAlignment = System.Drawing.StringAlignment.Center;
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnNext2
            // 
            this.btnNext2.BackColor = System.Drawing.Color.Transparent;
            this.btnNext2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnNext2.Image = null;
            this.btnNext2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNext2.Location = new System.Drawing.Point(0, 84);
            this.btnNext2.Name = "btnNext2";
            this.btnNext2.Size = new System.Drawing.Size(69, 52);
            this.btnNext2.TabIndex = 35;
            this.btnNext2.Text = "Next";
            this.btnNext2.TextAlignment = System.Drawing.StringAlignment.Center;
            this.btnNext2.Click += new System.EventHandler(this.btnNext2_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackImage = ((System.Drawing.Image)(resources.GetObject("$this.BackImage")));
            this.ClientSize = new System.Drawing.Size(1260, 614);
            this.Controls.Add(this.lblLost);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnInst);
            this.Controls.Add(this.lblVersus);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "Main";
            this.Style = MetroFramework.MetroColorStyle.Green;
            this.Text = "QuizOP";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.TransparencyKey = System.Drawing.Color.Teal;
            this.Load += new System.EventHandler(this.Main_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnInst.ResumeLayout(false);
            this.pnInst.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnInst;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblNm1;
        private System.Windows.Forms.Label lblNM2;
        private System.Windows.Forms.Label lblNM3;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Team;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Timer CountdownTimer;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label lblNM4;
        private System.Windows.Forms.Label lbl_NM4;
        private System.Windows.Forms.Label lbl_NM1;
        private System.Windows.Forms.Label lbl_NM2;
        private System.Windows.Forms.Label lbl_NM3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblVersus;
        private iTalk.iTalk_Button_1 btnNext;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label lblCountTeam2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblQuestTeam2;
        private System.Windows.Forms.Panel panel7;
        private iTalk.iTalk_HeaderLabel lblTeam2;
        private iTalk.iTalk_HeaderLabel lblTeam1;
        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.Label lblPoint2;
        private System.Windows.Forms.Label lblQuest2;
        private System.Windows.Forms.Label lblQuest3;
        private System.Windows.Forms.Label lblQuest8;
        private System.Windows.Forms.Label lblQuest7;
        private System.Windows.Forms.Label lblQuest6;
        private System.Windows.Forms.Label lblQuest5;
        private System.Windows.Forms.Label lblQuest4;
        private System.Windows.Forms.Label lblQuest10;
        private System.Windows.Forms.Label lblQuest9;
        private System.Windows.Forms.Label lblQuestTeam6;
        private System.Windows.Forms.Label lblQuestTeam4;
        private System.Windows.Forms.Label lblQuestTeam3;
        private System.Windows.Forms.Label lblWrong2;
        private System.Windows.Forms.Label lblCorrect2;
        private System.Windows.Forms.Label lblWrong;
        private System.Windows.Forms.Label lblCorrect;
        private iTalk.iTalk_Button_1 btnNext2;
        private System.Windows.Forms.Label lblLost;
    }
}