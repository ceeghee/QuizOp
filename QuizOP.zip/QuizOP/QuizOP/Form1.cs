﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace QuizOP
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtTeam.Focus();
            btnSubmit2.Enabled = false;
            btnSubmit2.Visible = false;
            connections.getData();
            lblDetails.Visible = false;
            
        }

        public void Reset()
        {
            txtTeam.Text = "";
            txttm1.Text = "";
            txttm2.Text = "";
            txttm3.Text = "";
            txttm4.Text = "";
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //conn = new SqlConnection(cs.connect);

            //if (txtTeam.Text == "")
            //{
            //    MessageBox.Show("No Team Name Selected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    txtTeam.Focus();
            //    return;
            //}
            //if (txttm1.Text == "")
            //{
            //    MessageBox.Show("Team Member 1 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    txttm1.Focus();
            //    return;
            //}
            //if (txttm2.Text == "")
            //{
            //    MessageBox.Show("Team Member 2 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    txttm2.Focus();
            //    return;
            //}
            //if (txttm3.Text == "")
            //{
            //    MessageBox.Show("Team Member 3 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    txttm3.Focus();
            //    return;
            //}
            //if (txttm4.Text == "")
            //{
            //    MessageBox.Show("Team Member 4 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    txttm4.Focus();
            //    return;
            //}

            //try
            //{
                
            //    conn = new SqlConnection(cs.connect);
            //    conn.Open();
            //    string cb = "insert into [Table](TeamName,User1,User2,User3,User4) VALUES ('" + txtTeam.Text + "','" + txttm1.Text + "','" + txttm2.Text + "','" + txttm3.Text + "','" + txttm4.Text + "')";
            //    cmd = new SqlCommand(cb);
            //    cmd.Connection = conn;
            //    cmd.ExecuteReader();
            //    conn.Close();
            //    MessageBox.Show("Welcome " + txtTeam.Text, "Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //    Reset();

            //    //btnSubmit.Visible = false;
            //    //btnSubmit.Enabled = false;

               
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }

        public void _submit1()
        {
            try
            {
                connections.sqL = "INSERT INTO teams(mem1, mem2, mem3, mem4,teamname) VALUES('" + txttm1.Text + "', '" + txttm2.Text + "', '" + txttm3.Text.Trim() + "', '" + txttm4.Text+ "', '" + txtTeam.Text + "')";
                connections.ConnDB();
                connections.cmd = new MySqlCommand(connections.sqL, connections.conn);
                connections.cmd.ExecuteNonQuery();
                MessageBox.Show("Welcome " + txtTeam.Text, "Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Reset();
                btnSubmit.Visible = false;
                btnSubmit.Enabled = false;

                btnSubmit2.Visible = true;
                btnSubmit2.Enabled = true;

                //AddStockIn();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                connections.cmd.Dispose();
                connections.conn.Close();
            }
        }
        public void _submit2()
        {
            try
            {
                connections.sqL = "INSERT INTO team2(mem1, mem2, mem3, mem4,teamname) VALUES('" + txttm1.Text + "', '" + txttm2.Text + "', '" + txttm3.Text.Trim() + "', '" + txttm4.Text + "', '" + txtTeam.Text + "')";
                connections.ConnDB();
                connections.cmd = new MySqlCommand(connections.sqL, connections.conn);
                connections.cmd.ExecuteNonQuery();
                MessageBox.Show("Welcome " + txtTeam.Text.ToUpper(), "Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Reset();
               
                btnSubmit2.Visible = false;
                btnSubmit2.Enabled = false;

                Hide();
                Main main = new Main();
                main.Show();


                //AddStockIn();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                connections.cmd.Dispose();
                connections.conn.Close();
            }
        }
        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
           // conn = new SqlConnection(cs.connect);

            if (txtTeam.Text == "")
            {
                MessageBox.Show("No Team Name Selected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTeam.Focus();
                return;
            }
            if (txttm1.Text == "")
            {
                MessageBox.Show("Team Member 1 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm1.Focus();
                return;
            }
            if (txttm2.Text == "")
            {
                MessageBox.Show("Team Member 2 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm2.Focus();
                return;
            }
            if (txttm3.Text == "")
            {
                MessageBox.Show("Team Member 3 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm3.Focus();
                return;
            }
            if (txttm4.Text == "")
            {
                MessageBox.Show("Team Member 4 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm4.Focus();
                return;
            }
            _submit1();
            lblDetails.Visible = true;

            //try
            //{

            // //   conn = new SqlConnection(cs.connect);
            //    conn.Open();
            //    string cb = "insert into [Table](TeamName,User1,User2,User3,User4) VALUES ('" + txtTeam.Text + "','" + txttm1.Text + "','" + txttm2.Text + "','" + txttm3.Text + "','" + txttm4.Text + "')";
            //    cmd = new SqlCommand(cb);
            //    cmd.Connection = conn;
            //    cmd.ExecuteReader();
            //    conn.Close();
            //    MessageBox.Show("Welcome " + txtTeam.Text, "Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //    Reset();

            //    btnSubmit.Visible = false;
            //    btnSubmit.Enabled = false;

            //    btnSubmit2.Visible = true;
            //    btnSubmit2.Enabled = true;


            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }

        private void btnSubmit2_Click(object sender, EventArgs e)
        {
           // conn = new SqlConnection(cs.connect);

            if (txtTeam.Text == "")
            {
                MessageBox.Show("No Team Name Selected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTeam.Focus();
                return;
            }
            if (txttm1.Text == "")
            {
                MessageBox.Show("Team Member 1 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm1.Focus();
                return;
            }
            if (txttm2.Text == "")
            {
                MessageBox.Show("Team Member 2 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm2.Focus();
                return;
            }
            if (txttm3.Text == "")
            {
                MessageBox.Show("Team Member 3 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm3.Focus();
                return;
            }
            if (txttm4.Text == "")
            {
                MessageBox.Show("Team Member 4 Name Not Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttm4.Focus();
                return;
            }

            _submit2();


            //try
            //{

            // //   conn = new SqlConnection(cs.connect);
            //    //conn.Open();
            //    //string cb = "insert into [Table2](Team2Name,User1,User2,User3,User4) VALUES ('" + txtTeam.Text + "','" + txttm1.Text + "','" + txttm2.Text + "','" + txttm3.Text + "','" + txttm4.Text + "')";
            //    //cmd = new SqlCommand(cb);
            //    //cmd.Connection = conn;
            //    //cmd.ExecuteReader();
            //    //conn.Close();
            //   // MessageBox.Show("Welcome " + txtTeam.Text, "Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

               
              

            //    //btnSubmit2.Visible = false;
            //    //btnSubmit2.Enabled = false;

            //    //Hide();
            //    //Main main = new Main();
            //    //main.Show();


            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F12)
            {
                DatabaseConfig dc = new DatabaseConfig();
                dc.ShowDialog();
            }
        }

        private void btnConfigureDB_Click(object sender, EventArgs e)
        {
            DatabaseConfig db = new DatabaseConfig();
            db.Show();

        }
    }
}
