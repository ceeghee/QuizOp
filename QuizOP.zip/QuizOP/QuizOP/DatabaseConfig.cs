﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizOP
{
    public partial class DatabaseConfig : MetroFramework.Forms.MetroForm
    {
        public DatabaseConfig()
        {
            InitializeComponent();
        }

        private string TstServerMySQL;
        private string TstPortMySQL;
        private string TstUserNameMySQL;
        private string TstPwdMySQL;
        private string TstDBNameMySQL;
        
      
        private void DatabaseConfig_Load(object sender, EventArgs e)
        {
            //this.Location = new Point(178, 127);
            connections.getData();
            txtServerHost.Text = connections.ServerMySQL;
            txtPort.Text = connections.PortMySQL;
            txtUserName.Text = connections.UserNameMySQL;
            txtPassword.Text = connections.PwdMySQL;
            txtDatabase.Text = connections.DBNameMySQL;
        }

        private void cmdTest_Click_1(object sender, EventArgs e)
        {
            //Test database connection

            TstServerMySQL = txtServerHost.Text;
            TstPortMySQL = txtPort.Text;
            TstUserNameMySQL = txtUserName.Text;
            TstPwdMySQL = txtPassword.Text;
            TstDBNameMySQL = txtDatabase.Text;


            try
            {
                connections.conn.ConnectionString = "Server = '" + TstServerMySQL + "';  " + "Port = '" + TstPortMySQL + "'; " + "Database = '" + TstDBNameMySQL + "'; " + "user id = '" + TstUserNameMySQL + "'; " + "password = '" + TstPwdMySQL + "'";


                connections.conn.Open();

                MessageBox.Show("Test connection successful");

            }
            catch
            {
                MessageBox.Show("The system failed to establish a connection");

            }
            connections.DisconnMy();
        }

        private void cmdSave_Click_1(object sender, EventArgs e)
        {
            TstServerMySQL = txtServerHost.Text;
            TstPortMySQL = txtPort.Text;
            TstUserNameMySQL = txtUserName.Text;
            TstPwdMySQL = txtPassword.Text;
            TstDBNameMySQL = txtDatabase.Text;

            try
            {
                connections.conn.ConnectionString = "Server = '" + TstServerMySQL + "';  " + "Port = '" + TstPortMySQL + "'; " + "Database = '" + TstDBNameMySQL + "'; " + "user id = '" + TstUserNameMySQL + "'; " + "password = '" + TstPwdMySQL + "'";
                connections.conn.Open();

                connections.DBNameMySQL = txtDatabase.Text;
                connections.ServerMySQL = txtServerHost.Text;
                connections.UserNameMySQL = txtUserName.Text;
                connections.PortMySQL = txtPort.Text;
                connections.PwdMySQL = txtPassword.Text;

                connections.SaveData();
                this.Close();
            }
            catch
            {
                MessageBox.Show("The system failed to establish a connection");
            }
            connections.DisconnMy();
            //save database
        }

        private void cmdClose_Click_1(object sender, EventArgs e)
        {
             Form1 log = new Form1();
            log.Show();
            this.Close();

        }
    }
}
