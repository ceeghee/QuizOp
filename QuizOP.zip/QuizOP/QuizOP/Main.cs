﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;

namespace QuizOP
{
    public partial class Main : MetroFramework.Forms.MetroForm
    {
        int progress = 15;
        int point = 0;
        public Main()
        {
            InitializeComponent();
        }


        public void EnableRadioButtons()
        {
            radioButton1.Enabled = true;
            radioButton2.Enabled = true;
            radioButton3.Enabled = true;
            radioButton4.Enabled = true;
            radioButton5.Enabled = true;
            radioButton6.Enabled = true;
            radioButton7.Enabled = true;
            radioButton8.Enabled = true;
        }

        public void DisableRadioButtons()
        {
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;
            radioButton4.Enabled = false;
            radioButton5.Enabled = false;
            radioButton6.Enabled = false;
            radioButton7.Enabled = false;
            radioButton8.Enabled = false;
        }
        public void Enable_Start_Timer()
        {
            //CountdownTimer.Enabled = true;
            do
            {
                progress = 15;

                progress += 1;
                lblCount.ForeColor = Color.Green;
                lblCountTeam2.ForeColor = Color.Green;
                if (progress == 5)
                {
                    lblCount.ForeColor = Color.Red;
                    lblCountTeam2.ForeColor = Color.Red;
                }
            }

            while (radioButton3.Enabled == false && radioButton1.Enabled == false && radioButton2.Enabled == false && radioButton3.Enabled == false);


            CountdownTimer.Start();


        }
        public void Disable_Stop_Timer()
        {
            CountdownTimer.Enabled = false;
            CountdownTimer.Stop();


        }

        public void Uncheck_RadioButtons()
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            radioButton5.Checked = false;
            radioButton6.Checked = false;
            radioButton7.Checked = false;
            radioButton8.Checked = false;
        }
        private void Main_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            lblVersus.Visible = false;
            lblQuestion.Text = "What is the largest animal ever to live on Earth?";
            radioButton1.Text = "blue Whale";
            radioButton2.Text = " Gorilla";
            radioButton3.Text = " Elephant";
            radioButton4.Text = "Dragon";

            lblQuestTeam2.Text = "What is the largest animal ever to live on Earth?";
            radioButton5.Text = "blue Whale";
            radioButton6.Text = " Gorilla";
            radioButton7.Text = " Elephant";
            radioButton8.Text = "Dragon";

            Getdata();
            _Getdata();
            CapData();
            _CapData();

            Disable_Stop_Timer();
            connections.getData();
            btnNext2.Visible = false;
            // this.label8.Location = new System.Drawing.Point(8, 13);

        }

        public void Questions()
        {


            lblQuestion.Text = "What is the largest animal ever to live on Earth?";
            radioButton1.Text = "blue Whale";
            radioButton2.Text = " Gorilla";
            radioButton3.Text = " Elephant";
            radioButton4.Text = "Dragon";
            if (radioButton1.Checked == true)
            {
                point = 5;
                lblPoints.Text = "Points " + point.ToString();
                lblCorrect.Visible = true;
            }
            else
            {
                point = 0;
                lblPoints.Text = "Points " + point.ToString();
                lblWrong.Visible = true;
            }

            
            
            lblQuestTeam2.Text = "What is the largest animal ever to live on Earth?";
            radioButton5.Text = "blue Whale";
            radioButton6.Text = " Gorilla";
            radioButton7.Text = " Elephant";
            radioButton8.Text = "Dragon";

            if (radioButton5.Checked == true)
            {
                point = 5;
                lblPoint2.Text = "Points " + point.ToString();
                lblCorrect2.Visible = true;
            }
            else
            {
                point = 0;
                lblPoint2.Text = "Points " + point.ToString();
                lblWrong2.Visible = true;
            }

            //string[] quest = new string[] { "matt", "bim" };

            //quest[0] = "What is the largest animal ever to live on Earth?";
            //quest[1] = "What animal represent the year 2000 on the Chinese calander?";
            //quest[2] = "Which of theses is not a type of Primate?";
            //quest[3] = "How many spots are there on a traditional 6-sided dice?";
            //quest[4] = "what does an animal produce when it lactates?";
            //quest[5] = "What is a website telling you if it serves you a '404 error'?";
            //quest[6] = "Where is fireworks first known to have been discovered?";
            //quest[7] = "From which language does the term R.S.V.P originate?";
            //quest[8] = "What is called a lorry in Britain?";
            //quest[9] = "How is 4:00pm expressed in military time? ";
            //quest[10] = "Mordern computer chip are primarily composed of what element?";
            //quest[11] = "How many colours are on the Nigerian flag?";
            //quest[12] = "Including the bottom how many sides does a pyramid have?";
            //quest[13] = "Which of these is not a type of rock?";
            //quest[14] = "who is the current president of the united states of America?";
            //quest[15] = "What is produced during photosynthesis?";
            //quest[16] = "The First Programming Language ever was?";
            //quest[17] = "Where are all the components of the CPU placed?";
            //quest[18] = "How many bones are in the human body?";
            //quest[19] = "How many brains does an octopus have?";
            //quest[20] = "What is the chemical formula for H3O stand for?";

            //foreach (string item in quest)
            //{
            //    this.lblQuestion.Text = item[0].ToString();
            //}



        }
        public void Getdata()
        {


            try
            {
                connections.sqL = "SELECT (idteams),(mem1),(mem2),(mem3),(mem4),(teamname)  FROM teams ";
                connections.ConnDB();
                connections.cmd = new MySqlCommand(connections.sqL, connections.conn);
                connections.dr = connections.cmd.ExecuteReader();

                lblID.Text = "";
                lblTeam.Text = "";
                lblNm1.Text = "";
                lblNM2.Text = "";
                lblNM3.Text = "";
                lblNM4.Text = "";

                if (connections.dr.Read() == true)
                {

                    lblID.Text = connections.dr[0].ToString();
                    lblNm1.Text = connections.dr[1].ToString();
                    lblNM2.Text = connections.dr[2].ToString();
                    lblNM3.Text = connections.dr[3].ToString();
                    lblNM4.Text = connections.dr[4].ToString();
                    lblTeam.Text = "TEAM " + connections.dr[5].ToString();

                }
                //else
                //{
                //    lblProductNo.Text = "1";
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                connections.cmd.Dispose();
                connections.conn.Close();
            }
        }
        public void _Getdata()
        {

            try
            {
                connections.sqL = "SELECT (idteam2),(mem1),(mem2),(mem3),(mem4),(teamname) FROM team2 ";
                connections.ConnDB();
                connections.cmd = new MySqlCommand(connections.sqL, connections.conn);
                connections.dr = connections.cmd.ExecuteReader();

                lbl_ID.Text = "";
                lbl_Team.Text = "";
                lbl_NM1.Text = "";
                lbl_NM2.Text = "";
                lbl_NM3.Text = "";
                lbl_NM4.Text = "";


                while (connections.dr.Read() == true)
                {

                    lbl_ID.Text = connections.dr[0].ToString();
                    lbl_NM1.Text = connections.dr[1].ToString();
                    lbl_NM2.Text = connections.dr[2].ToString();
                    lbl_NM3.Text = connections.dr[3].ToString();
                    lbl_NM4.Text = connections.dr[4].ToString();
                    lbl_Team.Text = "TEAM " + connections.dr[5].ToString().ToUpper();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                connections.cmd.Dispose();

                connections.conn.Close();
            }
        }
        public void CapData()
        {

            try
            {
                connections.sqL = "SELECT (teamname) FROM team2 ";
                connections.ConnDB();
                connections.cmd = new MySqlCommand(connections.sqL, connections.conn);
                connections.dr = connections.cmd.ExecuteReader();

                lblTeam2.Text = "";

                while (connections.dr.Read() == true)
                {


                    lblTeam2.Text = "TEAM " + connections.dr[0].ToString().ToUpper();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                connections.cmd.Dispose();

                connections.conn.Close();
            }
        }
        public void _CapData()
        {
            try
            {
                connections.sqL = "SELECT (teamname) FROM teams ";
                connections.ConnDB();
                connections.cmd = new MySqlCommand(connections.sqL, connections.conn);
                connections.dr = connections.cmd.ExecuteReader();

                lblTeam1.Text = "";

                while (connections.dr.Read() == true)
                {


                    lblTeam1.Text = "TEAM " + connections.dr[0].ToString().ToUpper();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                connections.cmd.Dispose();

                connections.conn.Close();
            }
        }
        private void pnInst_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = true;
            lblVersus.Visible = true;
            pnInst.Visible = false;
            pnInst.Enabled = false;
            panel3.Visible = true;
            Enable_Start_Timer();
            


            //if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true || radioButton4.Checked == true && radioButton5.Checked == true || radioButton6.Checked == true || radioButton7.Checked == true || radioButton8.Checked == true)
            //{
            //    //if (radioButton5.Checked == true || radioButton6.Checked == true || radioButton7.Checked == true || radioButton8.Checked == true)
            //    //{
            //    //    btnNext.Enabled = false;
            //    //}
            //    btnNext.Visible = true;
            //}
            //else
            //{
            //    btnNext.Visible = false;
            //}

        }
        public void checkes()
        {
            if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true || radioButton4.Checked == true)
            {
                if (radioButton5.Checked == true || radioButton6.Checked == true || radioButton7.Checked == true || radioButton8.Checked == true)
                {
                    //btnNext.Enabled = false;
                    btnNext.Visible = true;
                }

            }
            else
            {
                btnNext.Visible = false;
            }
        }
        private void CountdownTimer_Tick(object sender, EventArgs e)
        {
            progress -= 1;
            Console.Beep();
            checkes();
            if (progress == 5)
            {
                lblCount.ForeColor = Color.Red;
                lblCountTeam2.ForeColor = Color.Red;
            }
            if (progress == 0)
            {
                Disable_Stop_Timer();
                DisableRadioButtons();

                btnNext.Enabled = true;
                btnNext.Visible = true;
                progress = 0;

                // lblCount.Text = progress.ToString() + "Second";

            }


            lblCount.Text = progress.ToString() + "Seconds";
            lblCountTeam2.Text = progress.ToString() + "Seconds";



        }

        private void btnNext_Click(object sender, EventArgs e)
        {

            EnableRadioButtons();
            Enable_Start_Timer();
            Uncheck_RadioButtons();

            if (radioButton1.Checked == true)
            {
                point = 5;
                lblPoints.Text = "Point : " + point.ToString();
                lblCorrect.Visible = true;

            }
            else
            {
                point = 0;
                lblPoints.Text = "Point :  " + point.ToString();
                lblWrong.Visible = true;

            }


            if (radioButton6.Checked == true)
            {
                point = 5;
                lblPoint2.Text = "Point : " + point.ToString();
                lblCorrect2.Visible = true;
            }
            else
            {
                point = 0;
                lblPoint2.Text = "Point : " + point.ToString();
                lblWrong2.Visible = true;
            }

            Thread.Sleep(2000);


            lblQuestion.Visible = false;
            lblQuestTeam2.Visible = false;
            btnNext.Enabled = false;
            btnNext.Visible = false;
            btnNext2.Visible = true;
            lblQuestTeam3.Visible = true;
            lblQuest2.Visible = true;

            lblQuest2.Text = "What animal represent the year 2000 on the Chinese calander?";
            lblQuestTeam3.Text = "What animal represent the year 2000 on the Chinese calander?";

            radioButton1.Text = "Lion";
            radioButton2.Text = " Wolf";
            radioButton3.Text = " Dragon";
            radioButton4.Text = "Snake";

             radioButton5.Text = "Lion";
            radioButton6.Text = " Wolf";
            radioButton7.Text = " Dragon";
            radioButton8.Text = "Snake";




        }

        private void btnNext2_Click(object sender, EventArgs e)
        {
            EnableRadioButtons();
            Enable_Start_Timer();
            Uncheck_RadioButtons();


            if (radioButton1.Checked == true)
            {
                point = 5;
                lblPoints.Text = "Point : " + point.ToString();
                lblCorrect.Visible = true;

            }
            else
            {
                point = 0;
                lblPoints.Text = "Point :  " + point.ToString();
                lblWrong.Visible = true;

            }


            if (radioButton6.Checked == true)
            {
                point = 5;
                lblPoint2.Text = "Point : " + point.ToString();
                

                Thread.Sleep(3000);
                lblCorrect2.Visible = false;
            }
            else
            {
                point = 0;
                lblPoint2.Text = "Point : " + point.ToString();
                lblWrong2.Visible = true;

                Thread.Sleep(3000);
                
            }

            Thread.Sleep(2000);


            CountdownTimer.Stop();
            lblLost.Text = "SORRY YOU BOTH LOST";
            lblLost.Visible = true;
        }
    }
}
